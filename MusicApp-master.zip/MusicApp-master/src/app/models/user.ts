export class User {
    id: number;
    email: string;
    password: string;
    firstName: string;
    lastName: string;
}

// version 2

// export class Signup {
//     constructor (
//       public email: string,
//       public name: string,
//       public password: string,
//     ) {  }
//   }